

Credit= ModxBeast/Armaan

special thanks to 
Gta gamer
Modxking


Installation for add-on:

1.drag and drop artmcompass folder to= mods>update>x64>dlcpacks

2.Edit dlclist (mods>update>update.rpf>common>data>) and add this line-
<Item>dlcpacks:\artmcompass\</Item> in dlclist [ make sure to click on show in mods folder]
 
3.You are ready to go

your are all set

[spawncode] = artmcompass

[important] dont share or reuplaod on yt or site 
and if you are making video give credit
dont give mod link give channel link

Thankyou enjoy!!!!!!!!!!!!!!!!!!!!!!